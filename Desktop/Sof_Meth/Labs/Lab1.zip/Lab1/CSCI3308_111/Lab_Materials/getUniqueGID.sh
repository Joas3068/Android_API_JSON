wc -l tmp
