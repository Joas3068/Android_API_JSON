sed 's/[4]/a/g' cryptic.txt |
sed 's/[3]/e/g' |
sed 's/[1]/i/g' |
sed 's/[0]/o/g' |
sed 's/[5]/s/g' |
sed 's/[7]/t/g' 


echo 