<!-- Include Header Partial -->
<%- include ../layouts/header.ejs %>

<% if (messages.error) { %>
    <p style="color:red"><%- messages.error %></p>
<% } %>
<% if (messages.success) { %>
    <p style="color:green"><%- messages.success %></p>
<% } %>
<!-- The action attribute of the form refers to a item using its database id -->
<form action="/store/edit/<%= id %>" method="post" name="form1">
    <table width="25%" border="0">
        <tr>
            <td>Name</td>
            <td><input type="text" name="sname" id="name" value="<%= sname %>"/></td>
        </tr>
        <tr>
            <td>Quantity</td>
            <td><input type="text" name="qty" value="<%= qty %>"/></td>
        </tr>
        <tr>
            <td>Price</td>
            <td><input type="text" name="price" value="<%= price %>"/></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="Submit" value="Edit"/></td>
        </tr>
    </table>
    <input type="hidden" name="_method" value="PUT"/>
</form>


<!-- Include Footer Partial -->
<%- include ../layouts/footer.ejs %>